def displayarray (m):
    #assume m is a list of lists containg integer value
    for r in range(len(m)):
        for c in range(len(m[r])):
            print('%4d' % m[r][c])
        print()
    for row in m:
        for elements in row:
            print('%4d' % element, end="")
        print()
    for r in range(len(m)):
        row = m[r] # simple list
        for element in row:
            print('%4d' % element, end="")
        print()
def createarray(row, columns):
    listing = []
    count = 1
    for x in range(0, columns):
        innerlist = []
        for y in range(0, row):
            innerlist.append(count)
            count +=1
        listing.append(innerlist[:y + 1])
    print(listing)
            
        
                  
                   
def main():
    createarray(5,5)

if __name__ == '__main__':
    main()
