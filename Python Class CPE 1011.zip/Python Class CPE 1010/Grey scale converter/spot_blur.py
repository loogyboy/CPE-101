import sys
from pixel import *
def getblurred(image, row, col, reach):
    count = 0
    avg_r = 0
    avg_b = 0
    avg_g = 0
    for y in range(row - reach, row + reach + 1):
        if 0 <= y < len(image):
            for x in range(col - reach, col + reach +  1):
                if 0 <= x < len(image[0]):
                    count = count + 1
                    avg_r += image[y][x].r
                    avg_g += image[y][x].g
                    avg_b += image[y][x].b
    return Pixel(int(avg_r / count), int(avg_g/ count), int(avg_b / count))
#weightedpixel
def getweight(p1,p2, weight):
    r = p1.r * (2 - weight) + (weight - 1)* p2.r
    g = p1.g * (2 - weight) + (weight - 1)* p2.g
    b = p1.b * (2 - weight) + (weight - 1)* p2.b
    return Pixel(int(r), int(g), int(b))
#blur pixel
def bluring(image, cenr, cenc, row, col,radius, reach):
    rad = math.sqrt((row - cenr)**2 + (col - cenc)**2)
    if rad < 2*radius:
        avg = getblurred(image, row,col, reach)
        if rad <= radius:
            return avg
        else:
            newreach = int(reach*(1-(rad - radius)/radius))
            pix = getblurred(image, row, col, newreach)
            return pix
    else:
        image[row][col]
def getheader(file):
    line = file.readline()
    line = file.readline()
    lines = line.split()
    width = int(lines[0])
    height = int(lines[1])
    line = file.readline()
    colordepth = int(line)
    return width, height, colordepth
def getdata(file):
    lll = getheader(file)
    width = lll[0]
    height = lll[1]
    colordepth = lll[2]
    image = []
    color = []
    rows = []
    col = 0
    row = 0
    line = file.readline()
    print(line)
    while line != "":
        lines = line.split()
        for linesss in lines:
            color.append(int(linesss))
            if len(color) == 3:
                pix = Pixel(color[0], color[1], color[2])
                rows.append(pix)
                color.clear()
                col = col + 1
                if col == width:
                    col = 0
                    image.append(rows)
                    rows = []
        line = file.readline()
    return width, height, colordepth, image
def images(image, rowc, colc, rad, reach):
    blurs = []
    for x in range(len(image)):
        blurd = []
        for y in range(len(image[0])):
            bpx = bluring(image, rowc, colc, x, y, rad, reach)
            blurd.append(bpx)
        blurs.append(blurd)
    print(blurs)
    return blurs
def write(name, colordepth, image):
    filenewname = name.strip(".ppm")
    encodename = (filenewname + "_blurred.ppm")
    fileout = open(encodename, "w")
    print(image)
    width = len(image[0])
    height = len(image)
    fileout.write("P3\n")
    fileout.write(str(width) + " " + str(height) + "\n")
    fileout.write(str(colordepth) +  "\n")
    for x in range(height):
        for y in range(width):
            lll = image[x][y]
            fileout.write('{0} {1} {2}\n'.format(lll.r,lll.g,lll.b))
    fileout.close()
def main():
    if len(sys.argv) < 6:
        print("Usage: python spot_blur.py <image.ppm> <row> <col> <radius> [<reach>]")
        return
    filename = sys.argv[1]
    row = int(sys.argv[2])
    col = int(sys.argv[3])
    radius = int(sys.argv[4])
    reach = int(sys.argv[5])
    try:
        file = open(filename, 'r')
    except:
        print("unable to open " + filename)
        return
    a = getdata(file)
    weight = a[0]
    height = a[1]
    colordepth = a[2]
    image = a[3]
    file.close()
    blur = images(image, row, col, radius, reach)
    try:
        write(filename, colordepth, blur)
    except:
        print("Unable to create blurred file")
        return
    fileout.close()


if __name__ == "__main__":
    main()
