import sys
from pixel import *
def getdata(file):
    line = file.readline()
    line = file.readline()
    lines = line.split()
    width = int(lines[0])
    height = int(lines[1])
    line = file.readline()
    colordepth = int(line)
    return width, height, colordepth

def writedata(files, width,height,colordepth):
    files.write("P3\n")
    files.write(str(width) + " " + str(height) + "\n")
    files.write(str(colordepth) +  "\n")
    return
    

def decode( file, file_out):
    width, height, colordepth = getdata(file)
    writedata(file_out, width, height, colordepth)
    colors = []
    row = 0
    col = 0
    line = file.readline()
    while line != "":
        lines = line.split()
        for liners in lines:
            colors.append(int(liners))
            if len(colors) == 3:
                pixel = Pixel.decodePixel(colors, col,row)
                file_out.write(str(pixel) + "\n")
                colors.clear()
                col += 1
                if col == width:
                    col = 0
                    row += 1
        line = file.readline()

def main():
    if not len(sys.argv) == 2:
        print("Usage: python encode.py <image.ppm>")
        return
    filename = sys.argv[1]
    try:
        file = open(filename, 'r')
    except:
        print("unable to open " + filename)
        return
    try:
        filenewname = filename.strip("encoded.ppm")
        encodename = (filenewname + "decoded.ppm")
        fileout = open(encodename, "w")
    except:
        print("Unable to open " + file)
        file.close()
        return

    decode(file, fileout)
    file.close()
    fileout.close()


if __name__ == "__main__":
    main()
