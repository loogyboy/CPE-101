from quakeFuncs import *
import time
filenames = "quakes.txt"
def start():
    print()
    print("Earthquakes:")
    print("------------")
    quakes = read_quakes_from_file(filenames)
    for a in quakes:
        print("({0:3.2f}){1:>40} at {2} ({3:8.3f}, {4:6.3f})".format(a.mag, a.place, time_to_str(a.time), a.longitude, a.latitude))
    return quakes
def reprint(jjj):
    print("Earthquakes:")
    print("------------")
    quakes = jjj
    for a in quakes:
        print("({0:3.2f}){1:>40} at {2} ({3:8.3f}, {4:6.3f})".format(a.mag, a.place, time_to_str(a.time), a.longitude, a.latitude))
def options():
    print()
    print("Options:")
    print("  (s)ort")
    print("  (f)ilter")
    print("  (n)ew quakes")
    print("  (q)uit")
    print()
def write_to_file(orig, names):
    file = open(filenames, 'w')
    for qua in orig:
        file.write("{:s} {:s} {:s} {:s} {:s}\n".format(str(qua.mag), str(qua.longitude), str(qua.latitude), str(qua.time), qua.place))
def test(original, temp, inputs, sorteds):
    if(inputs == "q" or inputs == "Q"):
        write_to_file(original, filenames)
        exit()
    elif(inputs == "s" or inputs == "S"):
        l = input("Sort by (m)agnitude, (t)ime, (l)ongitude, or l(a)titude? ").strip()
        if(l == "m" or l == "M"):
            original = list(sort_mag(original))
            print()
            reprint(original)
            options()
            return original
        if(l == "t" or l == "T"):
            original = list(filter_by_time(original))
            print()
            reprint(original)
            options()
            return original
        if(l == "a" or l == "A"):
            original = list(filter_by_latitude(original))
            print()
            reprint(original)
            options()
            return original
        if(l == "l" or l == "L"):
            original = list(filter_by_longitude(original))
            print()
            reprint(original)
            options()
            return original
    elif(inputs == "f" or inputs == "F"):
        l = input("Filter by (m)agnitude or (p)lace? ").strip()
        if(l == "p" or l == "P"):
            pa = input("Search for what string? ").strip()
            temp = list(filter_by_place(original, pa))
            print()
            reprint(temp)
            options()
            return original
        if(l == "M" or l == "m"):
            lower = input("Lower bound: ").strip()
            upper = input("Upper bound: ").strip()
            temp = list(filter_by_mag(original, lower, upper))
            print()
            reprint(temp)
            options()
            return original
    elif(inputs == "n" or inputs == "N"):
        strs = get_json('http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/1.0_hour.geojson')
        add_new_quakes(original, strs)
        reprint(original)
        options()
        return original
def main():
    original = start()
    temp = None
    temp_sort = list(original)
    strs = None
    options()
    b = True
    while b == True:
        try:
            choice = input("Choice: ").strip()
            a = test(original, temp, choice, temp_sort)
            original = a
        except (EOFError):
            print("errorssss")
            break #end of file reached
        
        

                
        
        





if __name__ == "__main__":
    main()
