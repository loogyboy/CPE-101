from urllib.request import *
from json import *
from datetime import *
from operator import *

# GIVEN FUNCTIONS:
# Use these two as-is and do not change them
def get_json(url):
   ''' Function to get a json dictionary from a website.
       url - a string'''
   with urlopen(url) as response:
      html = response.read()
   htmlstr = html.decode("utf-8")
   return loads(htmlstr)

def time_to_str(time):
   ''' Converts integer seconds since epoch to a string.
       time - an int '''
   return datetime.fromtimestamp(time).strftime('%Y-%m-%d %H:%M:%S')    
   
# Add Earthquake class definition here   
   
class Earthquake:
    def __init__(self, place, mag, longitude, latitude, time):
        self.place = place
        self.mag = mag
        self.longitude = longitude
        self.latitude = latitude
        self.time = time
    def __eq__(self, other):
        """Override the default Equals behavior"""
        return self.place == other.place and self.mag == other.mag and self.longitude == other.longitude and self.latitude == other.latitude and self.time == other.time

# Required function - implement me!   
def read_quakes_from_file(filename):
   fin = open(filename, 'r')
   tlist = []
   for line in fin:
      line = line.strip()
      bro = line.split(" ")
      times = time_to_str(int(bro[3]))
      l = " ".join(bro[4:])
      tlist.append(Earthquake(l,float(bro[0]), float(bro[1]), float(bro[2]), int(bro[3])))
   fin.close()
   return tlist
def filter_by_time(quakes):
   templist = list(quakes)
   temppp = None
   temppp = sorted(templist, key=lambda earthquakes: earthquakes.time, reverse=True)
   return temppp
# Required function - implement me!
def sort_by_mag(quakes, low, high):
   templist = list(quakes)
   temppp = None
   k = 0
   for x in range(len(templist)):
      if (templist[x - k].mag <= float(low) or templist[x - k].mag >= float(high)):
         templist.pop(x - k)
         k = k + 1
   
def filter_by_mag(quakes, low, high):
   templist = list(quakes)
   temppp = None
   k = 0
   for x in range(len(templist)):
      if (templist[x - k].mag < float(low) or templist[x - k].mag > float(high)):
         templist.pop(x - k)
         k = k + 1
   temppp = list(templist)
   return temppp
def filter_by_latitude(quakes):
   templist = list(quakes)
   temppp = None
   temppp = sorted(templist, key=lambda earthquakes: earthquakes.latitude)
   return temppp
def filter_by_longitude(quakes):
   templist = list(quakes)
   temppp = None
   temppp = sorted(templist, key=lambda earthquakes: earthquakes.longitude)
   return temppp
def sort_mag(quakes):
   temppp = None
   temps = sorted(quakes, key=lambda earthquakes: earthquakes.mag, reverse=True)
   return temps
def add_new_quakes(quakes, new_quakes_dict):
   newQuakes = False
   ListofEarthquake = new_quakes_dict["features"]
   for f in ListofEarthquake:
      quake = quake_from_feature(f)
      if not quake in quakes:
         newQuakes = True
         quakes.append(quake)
   return newQuakes
   
     
# Required function - implement me!
def filter_by_place(quakes, word):   
   templist = list(quakes)
   temppp = None
   k = 0
   for x in range(len(templist)):
      m = templist[x-k].place
      l = m.lower()
      if word.lower() not in l:
         templist.pop(x - k)
         k = k + 1
   return templist

# Required function for final part - implement me too!   
def quake_from_feature(feature):
   equake = Earthquake(feature["properties"]["place"],
                       feature["properties"]["mag"],
                       feature["geometry"]["coordinates"][0],
                       feature["geometry"]["coordinates"][1],
                       int(feature["properties"]["time"]//1000))
   return equake
