def get_cages():
    list_inputs_str = []
    a = int(input("Number of cages: "))
    for x in range(a):
        input_string = ("Cage number %1d" % (x) + ": ")
        b = input(input_string)
        c = b.split(" ")
        for ooof in range(len(c)):
            c[ooof] = int(c[ooof])
        list_inputs_str.append(c)
    return list_inputs_str

def check_valid(puzzle, cages):
    if(check_rows_valid(puzzle)):
        if(check_columns_valid(puzzle)):
            if(check_cages_valid(puzzle, cages)):
                return True
    return False
def check_cages_valid(puzzle, cages):
    counter = len(cages)
    summing = 0
    #sum, number of grids, ########
    for l in range(len(cages)):
        top = cages[l][0]
        suming = top
        add_total = 0
        zero_count = 0
        for i in range(2,len(cages[l])):
            pos = cages[l][i]
            if(pos <= 24 and pos >= 0):
                f = pos // 5 #rows
                p = pos % 5 # cols
                if(puzzle[f][p] == 0):
                    zero_count += 1
                top = top - puzzle[f][p]
                if(top < 0):
                        return False
                if (zero_count > 0):
                    if(top == 0):
                        return False
                add_total += puzzle[f][p]
        if(add_total != suming and zero_count == 0):
            return False
    return True
def check_rows_valid(puzzle):
    for row in range(5):
        for nbrs in range(1,6):
            count = 0
            for col in range(5):
                if puzzle[row][col] == nbrs:
                    count = count + 1
                if count >= 2:
                    return False
                
    return True

def check_columns_valid(puzzle):
    for col in range(5):
        for nbrs in range(1,6):
            count = 0
            for row in range(5):
                if puzzle[row][col] == nbrs:
                    count = count + 1
                if count >= 2:
                    return False
    return True
