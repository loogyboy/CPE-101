import solverFuncs

def main():
    lastpuzzle=[]
    backtrack = 0
    checking_account = 0
    puzzle = []
    for x in range(5):
        abc = []
        for y in range(5):
            abc.append(0)
        puzzle.append(abc)
    valid = solverFuncs.get_cages()
    position = 0
    f = 0
    p = 0
    while True:
        if(position >= 25):    break
        #print(count)
        f = position // 5 
        p = position % 5
        if position < 0: break
        count = puzzle[f][p]
        if not(count + 1 == 6):
            count = count + 1
            puzzle[f][p] = count
            is_valid = solverFuncs.check_valid(puzzle, valid)
            checking_account = checking_account + 1
            if(is_valid == True):
                position = position + 1
        else:
            puzzle[f][p] = 0
            position = position - 1
            backtrack = backtrack + 1 
        
    print("\n---Solution---")
    for ll in range(5):
        print()
        for oo in range(5):
            print(puzzle[ll][oo], end=' ')
    print("\n")
    print("checks:", checking_account, end=" ")
    print("backtracks:", backtrack)

            
    
    

if __name__ == '__main__':
    main()
