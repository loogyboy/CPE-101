# Project 1
#
# Name: Peter Moe-Lange
# Instructor: J. Reichl
# Section: 15

import math

GRAVITY = 9.8

class inputs:
    a = "hi"
    b = "hi"
    c = "hi"
    d = None
    e = None

def poundsToKG(pounds):
    kilograms = pounds * 0.453592
    return kilograms
#search list
def getMassObject(object):
    objList = [["tomato", "t", 0.1],["banana cream pie", "p", 1.0],["rock", "r", 3.0],["lawn gnome", "g", 5.3],["light saber", "l", 9.07],["nothing", "n", 0.0]]
    a = 0
    while True:
        if(a >= len(objList)):
            inputs.d = objList[a-1]
            a -= 1
            break
        if(object == objList[a][1]):
            inputs.d = objList[a]
            break
        a += 1
    return objList[a][2]

def getVelocityObject(distance):
    velocityObject = (math.sqrt((GRAVITY * distance)/2))
    return velocityObject

def getVelocitySkater(massSkater, massObject, velObject):
    velocitySkater = (massObject * velObject)/massSkater
    return velocitySkater



