# Project 1
#
# Name: Peter Moe-Lange
# Instructor: J. Reichl
# Section: 15

import unittest
import math
from funcs import poundsToKG
from funcs import getMassObject
from funcs import getVelocityObject
from funcs import getVelocitySkater
from funcs import inputs

GRAVITY = 9.8

class TestCases(unittest.TestCase):

    def test_poundstokg(self):
        
        found = poundsToKG(0)
        expected = 0 * 0.453592
        self.assertAlmostEqual(found, expected)

        found = poundsToKG(20)
        expected = 20 * 0.453592
        self.assertAlmostEqual(found, expected)

    def test_massobject(self):

        
        found = getMassObject('l')
        expected = 9.07
        self.assertAlmostEqual(found, expected)

        found = getMassObject("twewewdsf")
        expected = 0.0
        self.assertAlmostEqual(found, expected)

    def test_velocityObject(self):
        
        found = getVelocityObject(10)
        expected = (math.sqrt((GRAVITY * 10)/2))
        self.assertAlmostEqual(found, expected)

        found = getVelocityObject(0)
        expected = (math.sqrt((GRAVITY * 0)/2))
        self.assertAlmostEqual(found, expected)

    def test_velocitySkater(self):
        
        found = getVelocitySkater(18,1,100)
        expected = ((1 * 100)/18)
        self.assertAlmostEqual(found, expected)

        found = getVelocitySkater(140,0.1,10)
        expected = ((0.1 * 10)/140)
        self.assertAlmostEqual(found, expected)

    
if (__name__ == '__main__'):
	unittest.main()
