import math
class Pixel:
    def __init__ (self, r,g,b):
        self.r = r
        self.g = g
        self.b = b

    def __eq__ (self, other):
        if not isinstance(other, Pixel):
            return False
        if self.r != other.r:
            return False
        if self.g != other.g:
            return False
        if self.b != other.b:
            return False
        return True
    def __repr__(self):
        return "{0} {1} {2}".format(self.r, self.g, self.b)

    def encodePixel(color, col, row):
        factor = (col + 3) * (row + 5)
        r = color[1] * factor
        g = color[2] * factor**2
        b = color[0] * factor**3
        pixel = Pixel(r,g,b)
        return pixel
    def decodePixel(color, col, row):
        factor = (col + 3) * (row + 5)
        r = color[0] / factor
        g = color[1] / factor**2
        b = color[2] / factor**3
        pixel = Pixel(int(b),int(r), int(g))
        return pixel
    #fullblur
    
            
                     
                     
                     
                    
                    
                
        
        
            
        
