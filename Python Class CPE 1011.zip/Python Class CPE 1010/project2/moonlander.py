# Project 2 - Moonlander
#
# Name: Peter Moe-Lange
# Instructor: Reichl

from landerFuncs import *
GRAVITY = 1.62
def main():
    showWelcome()
    rate = 1
    velocity = 0
    time = 0
    altitude = getAltitude()
    fuel = getFuel()
    print()
    print("LM state at retrorocket cutoff")
    displayLMState(time,altitude, velocity, fuel, 0)
    print()
    while True:
        if(fuel <= 0):
            rate = 0
        else:
            rate = getFuelRate(fuel)
        time = time + 1
        fuel = updateFuel(fuel, rate)
        acc = updateAcceleration(GRAVITY, rate)
        altitude = updateAltitude(altitude, velocity, acc)
        velocity = updateVelocity(velocity, acc)
        displayLMState(time, altitude, velocity, fuel, rate)

        print()
        if(altitude <= 0):
            break
        
    displayLMLandingStatus(velocity)
            
if(__name__=="__main__"):
    main()
