# Project 2 - Moonlander
#
# Name: Peter Moe-Lange
# Instructor: Reichl

def showWelcome():
   print("\nWelcome aboard the Lunar Module Flight Simulator")
   print("\n   To begin you must specify the LM's initial altitude")
   print("   and fuel level.  To simulate the actual LM use")
   print("   values of 1300 meters and 500 liters, respectively.")
   print("\n   Good luck and may the force be with you!\n")

fuel = 0   
def getFuel():
   while True:
      try:
         fuel = int(input("Enter the initial amount of fuel on board the LM (in liters): "))
         if (fuel <= 0):
            print("ERROR: Amount of fuel must be positive, please try again")
            raise ValueError
         break
      except ValueError:
         continue
   return fuel
alt = 0
def getAltitude():
   while True:
      try:
         alt = int(input("Enter the initial altitude of the LM (in meters): "))
         if (alt < 1 or alt > 9999):
            print('ERROR: Altitude must be between 1 and 9999, inclusive, please try again')
            raise ValueError
         break
      except ValueError:
         continue
   return alt
elapse = 'Elapsed Time:'
fuels = 'Fuel:'
rates = 'Rate:'
Alts = 'Altitude:'
Velocities = 'Velocity:'
nofuel = 'OUT OF FUEL - '
def displayLMState(elapsedTime, altitude, velocity, fuelAmount, fuelRate):
   if(altitude > 0):
      if(fuelAmount > 0):
         print('%13s' % elapse, end="")
         print('%5d' % elapsedTime, end=" s\n")
         print('%13s' % fuels, end="")
         print('%5d' % fuelAmount, end=" l\n")
         print('%13s' % rates, end="")
         print('%5d' % fuelRate, end=" l/s\n")
         print('%13s' % Alts, end="")
         print('%8.2f' % altitude, end=" m\n")
         print('%13s' % Velocities, end="")
         print('%8.2f' % velocity, end=" m/s\n")
      else:
         print('%14s' % nofuel, end="")
         print('%13s' % elapse, end="")
         print('%5d' % elapsedTime, end="")
         print('%10s' % Alts, end="")
         print('%8.2f' % altitude, end="")
         print('%10s' % Velocities, end="")
         print('%8.2f' % velocity, end="")
   else:
      print()
      print("LM state at landing/impact")
      print('%13s' % elapse, end="")
      print('%5d' % elapsedTime, end=" s\n")
      print('%13s' % fuels, end="")
      print('%5d' % fuelAmount, end=" l\n")
      print('%13s' % rates, end="")
      print('%5d' % fuelRate, end=" l/s\n")
      print('%13s' % Alts, end="")
      print('%8.2f' % altitude, end=" m\n")
      print('%13s' % Velocities, end="")
      print('%8.2f' % velocity, end=" m/s\n")
fuelrate = 0         
def getFuelRate(currentFuel):
   while True:
      try:
         fuelrate = int(input("Enter fuel rate (0-9, 0=freefall, 5=constant velocity, 9=max thrust): "))
         if (fuelrate < 0 or fuelrate > 9):
            print('ERROR: Fuel rate must be between 0 and 9, inclusive')
            raise ValueError
         break
      except ValueError:
         continue
   if(currentFuel <= fuelrate):
      return currentFuel
   return fuelrate
   
acceleration123 = 0 
def updateAcceleration(gravity, fuelRate):
   acceleration123 = gravity * (((fuelRate)/5)-1)
   return acceleration123
altitudes = 0	
def updateAltitude(altitude, velocity, acceleration):
   altidudes = altitude + velocity + (acceleration/2)
   if (altidudes < 0):
      return 0
   return altidudes
vel = 0
def updateVelocity(velocity, acceleration):
   vel = velocity + acceleration
   return vel
boo = 0
def updateFuel(fuel, fuelRate):
   boo = fuel - fuelRate
   return boo

def displayLMLandingStatus(velocity):
   if(velocity <= 0 and velocity >=-1):
      print("Status at landing - The eagle has landed!")
   elif(velocity < -1 and velocity > -10):
      print("Status at landing - Enjoy your oxygen while it lasts!")
   elif(velocity <=-10):
      print("Status at landing - Ouch - that hurt!")
   return
