# Project 2 - Moonlander
#
# Name: Peter Moe-Lange
# Instructor: Reichl

import unittest
from landerFuncs import *
GRAVITY = 1.62
class TestCases(unittest.TestCase):
   def test_update_acc1(self):
      self.assertAlmostEqual(updateAcceleration(1.62, 0), -1.62)
   def test_update_acc2(self):
      self.assertAlmostEqual(updateAcceleration(1.62, 5), 0)
   def test_update_velocity1(self):
      self.assertAlmostEqual(updateVelocity(5,3),8)
   def test_update_velocity2(self):
      self.assertAlmostEqual(updateVelocity(-2,-5),-7)
   def test_update_fuel1(self):
      self.assertAlmostEqual(updateFuel(5,2),3)
   def test_update_fuel2(self):
      self.assertAlmostEqual(updateFuel(-5, 2),-7)
   def test_update_Altitude1(self):
      self.assertAlmostEqual(updateAltitude(5,5,10),15)
   def test_update_Altitude2(self):
      self.assertAlmostEqual(updateAltitude(8,-3,-4),3)

   
      

      

# Run the unit tests.
if __name__ == '__main__':
   unittest.main()
