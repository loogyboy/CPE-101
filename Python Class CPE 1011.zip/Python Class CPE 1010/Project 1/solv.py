import solverFun

def main():
    lastpuzzle=[]
    backtrack = 0
    check = 0
    puzzle = []
    for x in range(5):
        abc = []
        for y in range(5):
            abc.append(0)
        puzzle.append(abc)
    WE_DID_IT_REDDIT = solverFuncs.inputting()
    count = 0
    while True:
        if(count >= 25):    break
        #print(count)
        f = count // 5 #rows
        p = count % 5 # cols
        ahhhhhhhhhhhhhhh_THHIIIISSSS_PRROROOOOJECT = puzzle[f][p]
        if(ahhhhhhhhhhhhhhh_THHIIIISSSS_PRROROOOOJECT + 1 == 6):
            puzzle[f][p] = 0
            count = count - 1
            backtrack = backtrack + 1
        else:
            ahhhhhhhhhhhhhhh_THHIIIISSSS_PRROROOOOJECT = ahhhhhhhhhhhhhhh_THHIIIISSSS_PRROROOOOJECT + 1
            puzzle[f][p] = ahhhhhhhhhhhhhhh_THHIIIISSSS_PRROROOOOJECT
            #print("output:", puzzle[f][p])
            o = solverFuncs.check_valid(puzzle, WE_DID_IT_REDDIT)
            check = check + 1
            if(o == True):
                count = count + 1


    print(puzzle)
    print(check)
    print(backtrack)

            
    
    

if __name__ == '__main__':
    main()
