def inputting():
    list_inputs_str = []
    a = int(input("Number of cages: "))
    for x in range(a):
        input_string = ("Cage number %1d" % (x) + ": ")
        b = input(input_string)
        c = b.split(" ")
        for ooof in range(len(c)):
            c[ooof] = int(c[ooof])
        list_inputs_str.append(c)
    print(list_inputs_str)
    return list_inputs_str

def check_valid(puzzle, cages):
    if(check_rows_valid(puzzle) == True):
        if(check_columns_valid(puzzle) == True):
            if(check_cages_valid(puzzle, cages) == True):
                return True
    return False
def check_cages_valid(puzzle, cages):
    counter = len(cages)
    summing = 0
    #sum, number of grids, ########
    for l in range(len(cages)):
        top = cages[l][0]
        for i in range(2,len(cages[l])):
            pos = cages[l][i]
            if(pos <= 24 and pos >= 0):
                f = pos // 5 #rows
                p = pos % 5 # cols
                top = top - puzzle[f][p]
            else:
                return False
        if(top < 0): 
            return False
    return True
def check_rows_valid(puzzle):
    for row in range(5):
        for nbrs in range(1,6):
            count = 0
            for col in range(5):
                if puzzle[row][col] == nbrs:
                    count = count + 1
                if count >= 2:
                    return False
    return True

def check_columns_valid(puzzle):
    for col in range(5):
        for nbrs in range(1,6):
            count = 0
            for row in range(5):
                if puzzle[row][col] == nbrs:
                    count = count + 1
                if count >= 2:
                    return False
    return True
    
                
def main():
    #inputting()
    a = [[3,5,2,1,4],[5,1,3,4,2],[2,4,1,50,3],[1,2,4,3,5],[4,3,5,2,1]]
    puzzle1 = [[3, 5, 2, 1, 4], [5, 1, 3, 4, 2], [2, 4, 1, 5, 3], [1, 2, 4, 3, 5], [4, 3, 5, 2, 1]]
    cages1 = [[9, 3, 0, 5, 6], [7, 2, 1, 2], [10, 3, 3, 8, 13], [14, 4, 4, 9, 14, 19], [3, 1,7], [8, 3, 10, 11, 16], [13, 4, 12, 17, 21, 22], [5, 2, 15, 20], [6, 3, 18, 23, 24]]
    #false partial
    puzzle2 = [[3, 5, 2, 1, 4], [5, 0, 2, 4, 2], [2, 4, 1, 5, 3], [1, 2, 4, 3, 5], [4, 3, 5, 2, 1]]
    print (check_cages_valid(puzzle2, cages1))

if __name__ == '__main__':
    main()
