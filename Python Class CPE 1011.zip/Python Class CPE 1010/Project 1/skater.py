# Project 1
#
# Name: Peter Moe-Lange
# Instructor: J. Reichl
# Section: 15

from funcs import inputs
from funcs import poundsToKG
from funcs import getMassObject
from funcs import getVelocityObject
from funcs import getVelocitySkater


def main():
    #function wide variables
    inf_c = False
    inf_b = False
    inf_a = False

    #takes in input from user
    inputs.c = float(input("How much do you weigh (pounds)? "))
    inputs.b = float(input("How far away is your professor (meters)? "))
    inputs.a  = input("Will you throw a rotten (t)omato, banana cream (p)ie,(r)ock, (l)ight saber, or lawn (g)nome?\n")
    #computes
    kilos = poundsToKG(float(inputs.c))

    #checks if any input is out of range of expected
    if (inputs.c <= 0): 
        inf_c  = True
    if(inputs.b <= 0):
        inf_b = True
    if(kilos == 0):
        inf_a == True

    #computes basic information
    mass = getMassObject(inputs.a)
    velocity = getVelocityObject(float(inputs.b))
    
    if(inf_c == False and inf_a == False):
        skaterVel = getVelocitySkater(kilos, mass, velocity)
    if(mass <= 0.1) : print("Nice throw! You're going to get an F!")
    if (mass > 0.1 and mass <= 1.0): print("Nice throw!Make sure your professor is OK.")
    if (mass > 1.0) :
        if(inputs.b < 20): print("Nice throw! How far away is the hospital?")
        if (inputs.b >= 20): print("Nice throw! RIP professor.")
    if(inf_c == True or inf_a == True):
        print("Velocity of skater: inf m/s")
    else:
        print("Velocity of skater: %.3f m/s" % skaterVel)
    try:
        #handles if skatervel cannot be computed due to zero skater weight
        if(skaterVel < 0.2): print("My grandmother skates faster than you!")       
    except:
        pass
    if((inf_c == True or inf_a == True) or skaterVel >= 1.0): print("Look out for that railing!!!")
    
if (__name__ == '__main__'):
    main()
