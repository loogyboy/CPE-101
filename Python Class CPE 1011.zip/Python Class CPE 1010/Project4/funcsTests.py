import funcs
import unittest
listings = funcs.create_2d("WAQHGTTWEECBMIVQQELSAZXWKWIIILLDWLFXPIPVPONDTMVAMNOEDSOYQGOBLGQCKGMMCTYCSLOACUZMXVDMGSXCYZUUIUNIXFNU")
class TestString(unittest.TestCase):
    def test_Puzzle(self):
        a = funcs.create_2d("WAQHGTTWEECBMIVQQELSAZXWKWIIILLDWLFXPIPVPONDTMVAMNOEDSOYQGOBLGQCKGMMCTYCSLOACUZMXVDMGSXCYZUUIUNIXFNU")
        b=[['W', 'A', 'Q', 'H', 'G', 'T', 'T', 'W', 'E', 'E'], ['C', 'B', 'M', 'I', 'V', 'Q', 'Q', 'E', 'L', 'S'], ['A', 'Z', 'X', 'W', 'K', 'W', 'I', 'I', 'I', 'L'], ['L', 'D', 'W', 'L', 'F', 'X', 'P', 'I', 'P', 'V'], ['P', 'O', 'N', 'D', 'T', 'M', 'V', 'A', 'M', 'N'], ['O', 'E', 'D', 'S', 'O', 'Y', 'Q', 'G', 'O', 'B'], ['L', 'G', 'Q', 'C', 'K', 'G', 'M', 'M', 'C', 'T'], ['Y', 'C', 'S', 'L', 'O', 'A', 'C', 'U', 'Z', 'M'], ['X', 'V', 'D', 'M', 'G', 'S', 'X', 'C', 'Y', 'Z'], ['U', 'U', 'I', 'U', 'N', 'I', 'X', 'F', 'N', 'U']]
        self.assertListAlmostEqual(a,b)
        
    def test_DOWN(self):
        words = "CALPOLY"
        a = funcs.check_vertical(words, listings, 10)
        b = (True, 'CALPOLY', 'down')
        self.assertAlmostEqual(a[0],b[0])
    def test_UP_false(self):
        words = "COMPILE"
        a = funcs.check_vertical(words, listings, 68)
        b = (False, 'COMPILE', 'false')
        self.assertAlmostEqual(a[0],b[0])
    def test_RIGHT(self):
        words = "UNIX"
        a = funcs.check_horizontal(words, listings, 93)
        b = (True, 'UNIX', 'down')
        self.assertAlmostEqual(a[0],b[0])
    def test_LEFT_false(self):
        words = "wdwa"
        a = funcs.check_vertical(words, listings, 75)
        b = (False)
        self.assertFalse(a[0])
    def test_LEFT_true(self):
        words = "VIM"
        a = funcs.check_horizontal(words, listings, 65)
        b = (False)
        self.assertFalse(a[0])
    def assertListAlmostEqual(self, l1, l2):
        self.assertEqual(len(l1), len(l2))
        for el1, el2 in zip(l1, l2):
            self.assertAlmostEqual(el1, el2)


if __name__ == '__main__':
    unittest.main()

