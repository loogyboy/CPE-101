import funcs
def main():
    listings = funcs.create_2d("WAQHGTTWEECBMIVQQELSAZXWKWIIILLDWLFXPIPVPONDTMVAMNOEDSOYQGOBLGQCKGMMCTYCSLOACUZMXVDMGSXCYZUUIUNIXFNU")
    print(listings)

if __name__ == "__main__":
    main()
