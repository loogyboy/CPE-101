listing = [[0 for x in range(10)] for y in range(10)]
def create_2d(stringy):
    listy = [[0 for x in range(10)] for y in range(10)] 
    count = 0
    for x in range(10):
        for y in range(10):
            listy[x][y] = stringy[count]
            count += 1
    listing = listy
    return listy

def check_vertical(words, listy, pos):
    try:
        row = pos // 10
        col = pos % 10
        wording = len(words)
        #if((row + wording) > 10 or (row - wording < 0)):
           # return False, words, "False"
        count = 0
        listys = []
        for x in range(len(words)):
            listys.append(listy[row + x][col])
        abc = "".join(listys)
        if abc == words:
            return True, words, "(DOWN)", pos
        if abc == words[::-1]:
            return True, words, "(UP)", pos + ((wording - 1) * 10)
        return False, words, "False"
    except:
        return False, words, "False"
    

def check_horizontal(words, listy, pos):
    try:
        row = pos // 10
        col = pos % 10
        wording = len(words)
       # if((col + wording) > 9 or (col - wording < 0)):
     #       return False, words, "False"
        count = 0
        listys = []
        for x in range(len(words)):
            listys.append(listy[row][col + x])
        abc = "".join(listys)
        if abc == words:
            return True, words, "(FORWARD)", pos
        if abc == words[::-1]:
            return True, words, "(BACKWARD)", pos + (wording - 1)
        return False, words, "False"
    except:
        return False, words, "False"
    
                
    return False, words, "False"
    
    

