import funcs

def main():
    
    strings_100 = input()
    word_list_raw = input()
    d_array = funcs.create_2d(strings_100)
    word_list_filtered = word_list_raw.split(" ")
    print("Puzzle:")
    for a in range(10):
        print()
        for b in range(10):
            print(d_array[a][b], end="")
    print("\n")
    for a in range(len(word_list_filtered)):
        pos = 0
        for x in range(100):
            trus = funcs.check_vertical(word_list_filtered[a], d_array, pos)
            l = trus[0]
            rus = funcs.check_horizontal(word_list_filtered[a], d_array, pos)
            v = rus[0]
            if(l == True ):
                pos = trus[3]
                row = pos // 10
                col = pos % 10
                print(word_list_filtered[a] + ":", trus[2], "row:", row, "column:", col)
                break
            if(v == True):
                pos = rus[3]
                row = pos // 10
                col = pos % 10
                print(word_list_filtered[a] + ":", rus[2], "row:", row, "column:", col)
                break      
            if(pos == 99 and trus[0] == False and rus[0] == False) :
                print(word_list_filtered[a] + ": word not found")
                break
            pos += 1
    
    
    



if __name__ == "__main__":
    main()
